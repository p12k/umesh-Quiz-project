export class Login{
    constructor(
        public username ='',
        public password=''
    ){}
}