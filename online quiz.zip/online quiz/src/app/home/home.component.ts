import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators, NgForm } from '@angular/forms';
import { Login } from "src/app/home/home";
import { Router } from "@angular/router";


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
emailpattern="^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
login = new Login();

  constructor(private router:Router) { }

  ngOnInit() {
  }

  data:any
  save(userForm:NgForm){
    this.data=userForm.form.get('username')
  }
  
  onSubmit(){
  
   console.log(this.login.username);
   console.log(this.login.email); 
  }
 
}
