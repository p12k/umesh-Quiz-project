export class Login{


constructor(
public username ='',
public email='',
public password=''){}



}
    
