export interface Quiz{
    id:number;
    question:string;
    A:string;
    B:string;
    C:string;
    D:string;
    E:string;
    answer:string;
    selected:string;
}